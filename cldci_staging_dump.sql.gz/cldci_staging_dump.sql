-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: cldc_database
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asambleas`
--

DROP TABLE IF EXISTS `asambleas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asambleas` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('ordinaria','extraordinaria','especial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fecha_convocatoria` date NOT NULL,
  `fecha_asamblea` date NOT NULL,
  `quorum_minimo` int NOT NULL,
  `lugar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modalidad` enum('presencial','virtual','hibrida') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'presencial',
  `enlace_virtual` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('convocada','en_curso','finalizada','cancelada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'convocada',
  `asistentes_count` int DEFAULT NULL,
  `quorum_alcanzado` tinyint(1) DEFAULT NULL,
  `convocatoria_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asambleas_organizacion_id_estado_index` (`organizacion_id`,`estado`),
  KEY `asambleas_fecha_asamblea_estado_index` (`fecha_asamblea`,`estado`),
  CONSTRAINT `asambleas_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asambleas`
--

LOCK TABLES `asambleas` WRITE;
/*!40000 ALTER TABLE `asambleas` DISABLE KEYS */;
INSERT INTO `asambleas` VALUES ('03946404-1bdf-4773-be12-d07ee8dc51a9','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:41:53','2025-10-19 19:41:53'),('07b79ab7-8044-45d5-86e7-a7b2eb9d53da','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:41:32','2025-10-19 19:41:32'),('0a3d510a-1fae-40af-b271-2aaa822dee4b','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('139cd06d-a33b-4a82-9a8d-6179e2294a04','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:40:18','2025-10-19 19:40:18'),('1cbce0bd-e942-4a9f-8f0b-a2aa99ecefbc','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:43:06','2025-10-19 19:43:06'),('3a740f7b-3299-44a3-a46c-9d55ffcea625','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('3b53c921-3f86-4bf6-9e29-9aac2d604663','d2363643-ab0a-4d6a-b117-f99ab9cfee29','extraordinaria','Asamblea General Extraordinaria','Asamblea para discutir cambios en los estatutos','2025-10-14','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,'admin','2025-10-19 21:37:29','2025-10-19 21:37:29'),('3dad0142-c1d6-42f3-976e-b0b197e5632c','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:58:35','2025-10-19 19:58:35'),('43bc8275-e23e-4a30-ab54-0b2fc2cfdade','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:42:28','2025-10-19 19:42:28'),('4eea1a19-6983-4da8-bf0f-bd6f75365034','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:42:28','2025-10-19 19:42:28'),('649a3303-5f14-4908-8fe2-f0bdabbea3cc','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:42:12','2025-10-19 19:42:12'),('68697bc2-e7c6-448d-9d19-b7717998380c','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:42:12','2025-10-19 19:42:12'),('6db92aa1-688a-4c07-9f93-4f7824d73dd1','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:40:36','2025-10-19 19:40:36'),('7e41657b-fb34-4d18-bee2-266c1354772b','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:40:36','2025-10-19 19:40:36'),('86402595-2a76-4d93-bbc1-56e9fc734991','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea Ordinaria Mensual','Asamblea mensual de seguimiento','2025-10-17','2025-11-18',30,'Virtual - Zoom','virtual',NULL,'convocada',NULL,NULL,NULL,NULL,'admin','2025-10-19 21:37:29','2025-10-19 21:37:29'),('906278b9-c4e8-4bb4-b987-a2220a3011af','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:43:06','2025-10-19 19:43:06'),('a05ec92c-0db5-4d91-a34b-3f556c7bfb14','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:41:53','2025-10-19 19:41:53'),('b782d4f4-67c8-4969-bedd-1a61cddce255','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:41:32','2025-10-19 19:41:32'),('dedc5fde-52ce-4c94-bc48-3b8eba996236','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:40:18','2025-10-19 19:40:18'),('f8c6780a-9014-43a4-9435-89b4d95b1839','d2363643-ab0a-4d6a-b117-f99ab9cfee29','especial','Asamblea Extraordinaria - Modificación Estatutos','Asamblea para modificar los estatutos de la organización','2025-10-04','2025-10-26',75,'Sede Nacional CLDCI','hibrida','https://meet.google.com/abc-defg-hij','convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('fd741d2b-eef2-4161-9d05-fd5e26c556b3','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ordinaria','Asamblea General Ordinaria 2024','Asamblea para aprobar el presupuesto anual y rendición de cuentas','2025-09-19','2025-11-03',50,'Sede Nacional CLDCI','presencial',NULL,'convocada',NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:58:35','2025-10-19 19:58:35');
/*!40000 ALTER TABLE `asambleas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencia_asambleas`
--

DROP TABLE IF EXISTS `asistencia_asambleas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia_asambleas` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asamblea_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `miembro_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `presente` tinyint(1) NOT NULL DEFAULT '0',
  `modalidad` enum('presencial','virtual') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hora_registro` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `asistencia_asambleas_asamblea_id_miembro_id_unique` (`asamblea_id`,`miembro_id`),
  KEY `asistencia_asambleas_miembro_id_foreign` (`miembro_id`),
  CONSTRAINT `asistencia_asambleas_asamblea_id_foreign` FOREIGN KEY (`asamblea_id`) REFERENCES `asambleas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asistencia_asambleas_miembro_id_foreign` FOREIGN KEY (`miembro_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_asambleas`
--

LOCK TABLES `asistencia_asambleas` WRITE;
/*!40000 ALTER TABLE `asistencia_asambleas` DISABLE KEYS */;
INSERT INTO `asistencia_asambleas` VALUES ('54a46c22-ad2e-11f0-b453-ee8797acc114','03946404-1bdf-4773-be12-d07ee8dc51a9','11d132f0-56e7-476f-ab71-df1657b97588',1,'presencial','2025-10-19 20:58:14','2025-10-19 20:58:14','2025-10-19 20:58:14'),('54a6c945-ad2e-11f0-b453-ee8797acc114','03946404-1bdf-4773-be12-d07ee8dc51a9','19b82cb6-e3b2-4287-a592-271558397760',1,'presencial','2025-10-19 20:58:14','2025-10-19 20:58:14','2025-10-19 20:58:14'),('54a6fa90-ad2e-11f0-b453-ee8797acc114','03946404-1bdf-4773-be12-d07ee8dc51a9','290d92ec-db66-41e0-a0d7-51366b4c9656',1,'presencial','2025-10-19 20:58:14','2025-10-19 20:58:14','2025-10-19 20:58:14'),('54a70c14-ad2e-11f0-b453-ee8797acc114','03946404-1bdf-4773-be12-d07ee8dc51a9','2a20516a-9ac0-4107-8e57-839de429ef2f',1,'presencial','2025-10-19 20:58:14','2025-10-19 20:58:14','2025-10-19 20:58:14'),('54a716fd-ad2e-11f0-b453-ee8797acc114','03946404-1bdf-4773-be12-d07ee8dc51a9','3e65df3e-317f-4516-bfb7-1fe2e5234cf6',1,'presencial','2025-10-19 20:58:14','2025-10-19 20:58:14','2025-10-19 20:58:14');
/*!40000 ALTER TABLE `asistencia_asambleas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidatos`
--

DROP TABLE IF EXISTS `candidatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidatos` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `eleccion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `miembro_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cargo_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `propuesta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `biografia` text COLLATE utf8mb4_unicode_ci,
  `foto_campana` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `votos_recibidos` int NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `candidatos_eleccion_id_miembro_id_cargo_id_unique` (`eleccion_id`,`miembro_id`,`cargo_id`),
  KEY `candidatos_miembro_id_foreign` (`miembro_id`),
  KEY `candidatos_cargo_id_foreign` (`cargo_id`),
  CONSTRAINT `candidatos_cargo_id_foreign` FOREIGN KEY (`cargo_id`) REFERENCES `cargos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `candidatos_eleccion_id_foreign` FOREIGN KEY (`eleccion_id`) REFERENCES `elecciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `candidatos_miembro_id_foreign` FOREIGN KEY (`miembro_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidatos`
--

LOCK TABLES `candidatos` WRITE;
/*!40000 ALTER TABLE `candidatos` DISABLE KEYS */;
/*!40000 ALTER TABLE `candidatos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capacitaciones`
--

DROP TABLE IF EXISTS `capacitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capacitaciones` (
  `id` char(36) NOT NULL,
  `organizacion_id` char(36) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text,
  `tipo` varchar(255) NOT NULL,
  `modalidad` varchar(255) DEFAULT 'presencial',
  `fecha_inicio` timestamp NULL DEFAULT NULL,
  `fecha_fin` timestamp NULL DEFAULT NULL,
  `lugar` varchar(255) DEFAULT NULL,
  `enlace_virtual` varchar(255) DEFAULT NULL,
  `capacidad_maxima` int DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT '0.00',
  `certificado_template_url` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT 'programada',
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capacitaciones`
--

LOCK TABLES `capacitaciones` WRITE;
/*!40000 ALTER TABLE `capacitaciones` DISABLE KEYS */;
INSERT INTO `capacitaciones` VALUES ('94a04d65-ad30-11f0-b453-ee8797acc114',NULL,'Curso de LocuciÃ³n Profesional','CapacitaciÃ³n en tÃ©cnicas de locuciÃ³n','curso','presencial','2025-10-20 09:00:00','2025-10-22 17:00:00','Sede Nacional CLDCI',NULL,30,500.00,NULL,'programada',NULL,'2025-10-19 21:14:21','2025-10-19 21:14:21'),('94a06121-ad30-11f0-b453-ee8797acc114',NULL,'Taller de Periodismo Digital','Herramientas digitales para periodistas','taller','virtual','2025-10-25 14:00:00','2025-10-25 18:00:00','Virtual',NULL,50,0.00,NULL,'programada',NULL,'2025-10-19 21:14:21','2025-10-19 21:14:21'),('94a06809-ad30-11f0-b453-ee8797acc114',NULL,'Seminario de Ã‰tica PeriodÃ­stica','Principios Ã©ticos en el periodismo','seminario','hibrida','2025-10-30 10:00:00','2025-10-30 16:00:00','Sede Nacional CLDCI',NULL,40,200.00,NULL,'programada',NULL,'2025-10-19 21:14:21','2025-10-19 21:14:21'),('aceea8db-d924-4244-a6ad-966ed20d0a0a','d2363643-ab0a-4d6a-b117-f99ab9cfee29','Conferencia: Ética en los Medios','Conferencia magistral sobre ética periodística','conferencia','hibrida','2025-12-18 19:59:53',NULL,'Auditorio Nacional','https://youtube.com/live/abc123',200,0.00,NULL,'programada',NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('cba380e4-40eb-4c31-8a44-598844df7621','d2363643-ab0a-4d6a-b117-f99ab9cfee29','Taller de Periodismo Digital','Herramientas y técnicas para periodismo en medios digitales','taller','virtual','2025-12-03 19:59:53','2025-12-05 19:59:53',NULL,'https://meet.google.com/xyz-abc-def',50,300.00,NULL,'programada',NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('fa59566a-2534-47f0-b453-f3c1b755bace','d2363643-ab0a-4d6a-b117-f99ab9cfee29','Curso de Locución Profesional','Capacitación en técnicas de locución y presentación','curso','presencial','2025-11-18 19:59:53','2025-11-23 19:59:53','Sede Nacional CLDCI',NULL,25,500.00,NULL,'programada',NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53');
/*!40000 ALTER TABLE `capacitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargos`
--

DROP TABLE IF EXISTS `cargos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cargos` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `nivel` enum('nacional','seccional','especializado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `es_presidencia` tinyint(1) NOT NULL DEFAULT '0',
  `orden_prioridad` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargos`
--

LOCK TABLES `cargos` WRITE;
/*!40000 ALTER TABLE `cargos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cargos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cursos`
--

DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('profesional','tecnico','especializado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `modalidad` enum('presencial','virtual','hibrida') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `capacidad_maxima` int NOT NULL,
  `lugar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` enum('programada','en_curso','finalizada','cancelada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'programada',
  `costo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cursos_organizacion_id_estado_index` (`organizacion_id`,`estado`),
  CONSTRAINT `cursos_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursos`
--

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentos_legales`
--

DROP TABLE IF EXISTS `documentos_legales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentos_legales` (
  `id` char(36) NOT NULL,
  `organizacion_id` char(36) DEFAULT NULL,
  `tipo` enum('estatuto','reglamento','acta','resolucion','circular') NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text,
  `numero_documento` varchar(255) DEFAULT NULL,
  `fecha_emision` date NOT NULL,
  `fecha_vigencia` date DEFAULT NULL,
  `archivo_url` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentos_legales`
--

LOCK TABLES `documentos_legales` WRITE;
/*!40000 ALTER TABLE `documentos_legales` DISABLE KEYS */;
INSERT INTO `documentos_legales` VALUES ('484f2a75-6031-4037-a08f-d3b0b17ea62e','d2363643-ab0a-4d6a-b117-f99ab9cfee29','reglamento','Reglamento Interno','Reglamento interno de funcionamiento',NULL,'2024-01-15',NULL,'/documentos/reglamento-interno.pdf',1,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('4f49e738-015e-476d-a364-201f73b6a308','d2363643-ab0a-4d6a-b117-f99ab9cfee29','estatuto','Estatutos CLDCI 2024','Estatutos actualizados de la organización',NULL,'2024-01-01','2027-12-31','/documentos/estatutos-2024.pdf',1,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('76d15bdb-c39c-4259-a5cd-755f0aa7ae86','d2363643-ab0a-4d6a-b117-f99ab9cfee29','acta','Acta Asamblea General 2023','Acta de la asamblea general ordinaria 2023',NULL,'2023-12-15',NULL,'/documentos/acta-asamblea-2023.pdf',1,NULL,'2025-10-19 19:59:54','2025-10-19 19:59:54'),('87dcdb91-5cdf-440a-8a2e-5f6826cbda80','d2363643-ab0a-4d6a-b117-f99ab9cfee29','circular','Reconocimiento a Miembros Destacados','Reconocimiento a miembros por su labor excepcional','CIR-2025-001','2025-10-09',NULL,NULL,1,'admin','2025-10-19 21:37:48','2025-10-19 21:37:48'),('925eee9d-d45b-4cc9-8b9d-106a2cc57efe','d2363643-ab0a-4d6a-b117-f99ab9cfee29','resolucion','Nueva Política de Membresía','Se establecen nuevos requisitos para la membresía activa','RES-2025-001','2025-10-14',NULL,NULL,1,'admin','2025-10-19 21:37:48','2025-10-19 21:37:48');
/*!40000 ALTER TABLE `documentos_legales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elecciones`
--

DROP TABLE IF EXISTS `elecciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elecciones` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('nacional','seccional','especial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `estado` enum('preparacion','activa','finalizada','cancelada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'preparacion',
  `votos_totales` int NOT NULL DEFAULT '0',
  `votacion_abierta` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `elecciones_organizacion_id_estado_index` (`organizacion_id`,`estado`),
  CONSTRAINT `elecciones_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elecciones`
--

LOCK TABLES `elecciones` WRITE;
/*!40000 ALTER TABLE `elecciones` DISABLE KEYS */;
INSERT INTO `elecciones` VALUES ('3cf87968-f92e-4727-84c0-e2690d3d233e','d2363643-ab0a-4d6a-b117-f99ab9cfee29','Elecciones Presidenciales 2024','Elecciones para presidente de la organización','nacional','2025-11-18','2025-11-25','preparacion',0,0,NULL,'2025-10-19 19:43:07','2025-10-19 19:43:07'),('6869ce12-8fd0-4b42-a332-ae9505791ece','d2363643-ab0a-4d6a-b117-f99ab9cfee29','Elecciones Directiva Nacional 2025','Proceso electoral para elegir nueva directiva','nacional','2025-12-18','2025-12-23','preparacion',0,0,'admin','2025-10-19 21:37:48','2025-10-19 21:37:48');
/*!40000 ALTER TABLE `elecciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `electores`
--

DROP TABLE IF EXISTS `electores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `electores` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `padron_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `miembro_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `elegible` tinyint(1) NOT NULL DEFAULT '1',
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `electores_padron_id_miembro_id_unique` (`padron_id`,`miembro_id`),
  KEY `electores_miembro_id_foreign` (`miembro_id`),
  CONSTRAINT `electores_miembro_id_foreign` FOREIGN KEY (`miembro_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE,
  CONSTRAINT `electores_padron_id_foreign` FOREIGN KEY (`padron_id`) REFERENCES `padrones_electorales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `electores`
--

LOCK TABLES `electores` WRITE;
/*!40000 ALTER TABLE `electores` DISABLE KEYS */;
INSERT INTO `electores` VALUES ('4c461916-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','11d132f0-56e7-476f-ab71-df1657b97588',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c46dbf4-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','19b82cb6-e3b2-4287-a592-271558397760',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c46ec20-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','290d92ec-db66-41e0-a0d7-51366b4c9656',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c46f00d-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','2a20516a-9ac0-4107-8e57-839de429ef2f',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c46f7e6-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','3e65df3e-317f-4516-bfb7-1fe2e5234cf6',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c470301-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','3f833b16-de7a-415a-bad5-94a9a7f48f76',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c47092c-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','60bee083-1db0-47e4-8e9a-72f3a6f3b3ba',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c4712f8-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','7142fec3-f54a-4edc-b544-b414f977c112',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c471a47-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','7862d376-6306-4f26-8c4f-0340cef941b2',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c472125-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','821591a2-5572-4024-a42d-fce5c19afbda',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c475295-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','a83e280e-9ba7-4b30-9ccd-ab13de19fa1f',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c475a86-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','b299263f-2df3-4f15-ac36-6d4365482356',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c475d43-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','c98a946b-41f5-41d6-a42d-dc966750c213',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c4761fd-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','c9eceb32-5a5a-480d-9fc1-4afd8dda2081',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4c47684e-ad30-11f0-b453-ee8797acc114','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','cbbc725b-6e4a-4a5d-bc3a-3a6fbebb45aa',1,'Miembro elegible','2025-10-19 21:12:19','2025-10-19 21:12:19'),('4ef3d1b7-82ad-46b4-9898-db4c00b4c556','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','3087e0a5-1b6d-4fb7-a14b-866b1d601333',1,NULL,'2025-10-19 19:42:13','2025-10-19 19:42:13'),('58915152-d702-4478-a012-f977dcf886db','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','acd42815-6e27-43b1-8c7b-65dcd18145c5',1,NULL,'2025-10-19 19:42:13','2025-10-19 19:42:13'),('6552d147-c300-4334-bf53-5b132d8689ef','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','2472bd85-5b7e-4fa4-bf0e-df9ed7d459e1',1,NULL,'2025-10-19 19:42:13','2025-10-19 19:42:13'),('69593a73-c770-4caf-9a33-c55ef54ada0d','42ee4354-cd9b-4bc3-99eb-24e32f75f92b','3d524668-3d6d-403a-a0a4-30517588ba9c',1,NULL,'2025-10-19 19:42:13','2025-10-19 19:42:13');
/*!40000 ALTER TABLE `electores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscripciones_capacitacion`
--

DROP TABLE IF EXISTS `inscripciones_capacitacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscripciones_capacitacion` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacitacion_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `miembro_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_inscripcion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `asistio` tinyint(1) DEFAULT '0',
  `calificacion` decimal(3,1) DEFAULT NULL,
  `certificado_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscripciones_capacitacion`
--

LOCK TABLES `inscripciones_capacitacion` WRITE;
/*!40000 ALTER TABLE `inscripciones_capacitacion` DISABLE KEYS */;
INSERT INTO `inscripciones_capacitacion` VALUES ('a3d586f0-ad30-11f0-b453-ee8797acc114','94a04d65-ad30-11f0-b453-ee8797acc114','11d132f0-56e7-476f-ab71-df1657b97588','2025-10-19 21:14:46',1,8.5,NULL,NULL,'2025-10-19 21:14:46','2025-10-19 21:14:46'),('a3d5a230-ad30-11f0-b453-ee8797acc114','94a04d65-ad30-11f0-b453-ee8797acc114','19b82cb6-e3b2-4287-a592-271558397760','2025-10-19 21:14:46',1,9.0,NULL,NULL,'2025-10-19 21:14:46','2025-10-19 21:14:46'),('a3d5ab7c-ad30-11f0-b453-ee8797acc114','94a04d65-ad30-11f0-b453-ee8797acc114','290d92ec-db66-41e0-a0d7-51366b4c9656','2025-10-19 21:14:46',1,7.5,NULL,NULL,'2025-10-19 21:14:46','2025-10-19 21:14:46'),('a3d5b19b-ad30-11f0-b453-ee8797acc114','94a04d65-ad30-11f0-b453-ee8797acc114','2a20516a-9ac0-4107-8e57-839de429ef2f','2025-10-19 21:14:46',1,8.0,NULL,NULL,'2025-10-19 21:14:46','2025-10-19 21:14:46'),('a3d5b860-ad30-11f0-b453-ee8797acc114','94a04d65-ad30-11f0-b453-ee8797acc114','3e65df3e-317f-4516-bfb7-1fe2e5234cf6','2025-10-19 21:14:46',1,9.5,NULL,NULL,'2025-10-19 21:14:46','2025-10-19 21:14:46');
/*!40000 ALTER TABLE `inscripciones_capacitacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscripciones_cursos`
--

DROP TABLE IF EXISTS `inscripciones_cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscripciones_cursos` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `curso_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `miembro_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` enum('inscrito','asistio','completo','ausente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inscrito',
  `fecha_inscripcion` date NOT NULL,
  `monto_pagado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `observaciones` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inscripciones_cursos_curso_id_miembro_id_unique` (`curso_id`,`miembro_id`),
  KEY `inscripciones_cursos_miembro_id_foreign` (`miembro_id`),
  CONSTRAINT `inscripciones_cursos_curso_id_foreign` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inscripciones_cursos_miembro_id_foreign` FOREIGN KEY (`miembro_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscripciones_cursos`
--

LOCK TABLES `inscripciones_cursos` WRITE;
/*!40000 ALTER TABLE `inscripciones_cursos` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscripciones_cursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_access_log`
--

DROP TABLE IF EXISTS `member_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_access_log` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessing_user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessed_member_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_context` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_access_log_accessed_member_id_foreign` (`accessed_member_id`),
  KEY `member_access_log_organization_context_foreign` (`organization_context`),
  CONSTRAINT `member_access_log_accessed_member_id_foreign` FOREIGN KEY (`accessed_member_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE,
  CONSTRAINT `member_access_log_organization_context_foreign` FOREIGN KEY (`organization_context`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_access_log`
--

LOCK TABLES `member_access_log` WRITE;
/*!40000 ALTER TABLE `member_access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `miembros`
--

DROP TABLE IF EXISTS `miembros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `miembros` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre_completo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cedula` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci,
  `fecha_nacimiento` date DEFAULT NULL,
  `profesion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado_membresia` enum('activa','suspendida','inactiva','honoraria') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activa',
  `tipo_membresia` enum('fundador','activo','pasivo','honorifico','estudiante','diaspora') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `fecha_ingreso` date NOT NULL,
  `numero_carnet` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motivo_suspension` text COLLATE utf8mb4_unicode_ci,
  `fecha_suspension` date DEFAULT NULL,
  `institucion_educativa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pais_residencia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reconocimiento_detalle` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `miembros_email_unique` (`email`),
  UNIQUE KEY `miembros_numero_carnet_unique` (`numero_carnet`),
  KEY `miembros_estado_membresia_tipo_membresia_index` (`estado_membresia`,`tipo_membresia`),
  KEY `miembros_organizacion_id_estado_membresia_index` (`organizacion_id`,`estado_membresia`),
  CONSTRAINT `miembros_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `miembros`
--

LOCK TABLES `miembros` WRITE;
/*!40000 ALTER TABLE `miembros` DISABLE KEYS */;
INSERT INTO `miembros` VALUES ('01355dea-7b9d-484f-90f1-55dba0179a63','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 19 de CLDCI Seccional Sánchez Ramírez','miembro19@CLDCI-025.org','001-0000019-3','(809) 453-4988',NULL,NULL,'Periodista','activa','activo','2025-02-25','CLDCI-025-2025-019',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('029ff295-0c0f-4abc-976f-033cd1911d38','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 3 de CLDCI Seccional Santiago Rodríguez','miembro3@CLDCI-031.org','001-0000003-8','(809) 302-8562',NULL,NULL,'Locutor','activa','activo','2025-02-25','CLDCI-031-2025-003',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('03e345c5-e58b-4cbe-8aa3-8db252fa36c9','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 8 de CLDCI Seccional Azua','miembro8@CLDCI-002.org','001-0000008-6','(809) 509-4747',NULL,NULL,'Locutor','activa','estudiante','2024-11-20','CLDCI-002-2025-008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('09434d9e-e884-4d29-9dac-d3dfdefd0cb3','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 2 de CLDCI Seccional Sánchez Ramírez','miembro2@CLDCI-025.org','001-0000002-6','(809) 677-2778',NULL,NULL,'Comunicador','activa','activo','2025-05-17','CLDCI-025-2025-002',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('0e0928ba-54a0-426a-b6d9-10d2ae1436c5','d2363643-ab0a-4d6a-b117-f99ab9cfee29',NULL,'Ana González Fernández','ana.gonzalez@cldci.org','001-4567890-1','(809) 456-7890',NULL,NULL,'Periodista','suspendida','activo','2018-09-15','CLDCI-2018-004',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 08:09:25','2025-10-19 08:09:25'),('0f045211-d602-4b5c-9129-e837f6c9dea2','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 11 de CLDCI Seccional Azua','miembro11@CLDCI-002.org','001-0000011-4','(809) 588-4166',NULL,NULL,'Comunicador','activa','activo','2025-04-14','CLDCI-002-2025-011',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('11d132f0-56e7-476f-ab71-df1657b97588','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 3 de CLDCI Seccional Elías Piña','miembro3@CLDCI-008.org','001-0000003-6','(809) 264-1970',NULL,NULL,'Periodista','activa','fundador','2024-12-12','CLDCI-008-2025-003',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('1687f811-9b41-4bb9-9851-bb79f147b5a7','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 5 de CLDCI Seccional Santiago','miembro5@CLDCI-030.org','001-0000005-1','(809) 875-7623',NULL,NULL,'Comunicador','activa','estudiante','2025-05-10','CLDCI-030-2025-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('18b2ca4e-fb0b-4617-a35b-02f4668e5c40','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 14 de CLDCI Seccional Santiago Rodríguez','miembro14@CLDCI-031.org','001-0000014-3','(809) 954-8025',NULL,NULL,'Comunicador','activa','activo','2025-07-30','CLDCI-031-2025-014',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('19b82cb6-e3b2-4287-a592-271558397760','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 1 de CLDCI Seccional Santiago','miembro1@CLDCI-030.org','001-0000001-1','(809) 304-9975',NULL,NULL,'Comunicador','activa','fundador','2025-03-16','CLDCI-030-2025-001',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('1a59b6d1-9d49-4208-b285-a2294292e569','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 9 de CLDCI Seccional Sánchez Ramírez','miembro9@CLDCI-025.org','001-0000009-8','(809) 279-5272',NULL,NULL,'Periodista','activa','activo','2025-05-16','CLDCI-025-2025-009',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('1d72bced-7619-4dce-a786-145aae8b29b8','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 10 de CLDCI Seccional Santiago','miembro10@CLDCI-030.org','001-0000010-3','(809) 146-3267',NULL,NULL,'Periodista','activa','activo','2024-10-23','CLDCI-030-2025-010',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('20b2daca-d16f-48e8-a6da-d29e2cefd845','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 5 de CLDCI Seccional Azua','miembro5@CLDCI-002.org','001-0000005-3','(809) 221-1856',NULL,NULL,'Locutor','activa','estudiante','2024-11-20','CLDCI-002-2025-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('2468a2e6-205c-4d10-a7a6-5352835ff149','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 6 de CLDCI Seccional Santiago Rodríguez','miembro6@CLDCI-031.org','001-0000006-4','(809) 590-2376',NULL,NULL,'Comunicador','activa','activo','2024-10-20','CLDCI-031-2025-006',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('2472bd85-5b7e-4fa4-bf0e-df9ed7d459e1','d2363643-ab0a-4d6a-b117-f99ab9cfee29',NULL,'Carlos Martínez Díaz','carlos.martinez@cldci.org','001-3456789-0','(809) 345-6789',NULL,NULL,'Conductor','activa','activo','2021-03-10','CLDCI-2021-003',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 08:09:25','2025-10-19 08:09:25'),('28c3f6e4-b7ae-42a9-a787-1f57b57deff5','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 3 de CLDCI Seccional Santiago','miembro3@CLDCI-030.org','001-0000003-4','(809) 963-4151',NULL,NULL,'Periodista','activa','activo','2025-08-07','CLDCI-030-2025-003',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('290d92ec-db66-41e0-a0d7-51366b4c9656','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 2 de CLDCI Seccional Santiago','miembro2@CLDCI-030.org','001-0000002-8','(809) 332-8248',NULL,NULL,'Periodista','activa','fundador','2025-01-13','CLDCI-030-2025-002',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('2a20516a-9ac0-4107-8e57-839de429ef2f','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 18 de CLDCI Seccional Santiago','miembro18@CLDCI-030.org','001-0000018-2','(809) 474-7238',NULL,NULL,'Comunicador','activa','fundador','2024-11-20','CLDCI-030-2025-018',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('2a743ebf-c22f-44a4-b7ec-1277e3e494f2','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 20 de CLDCI Seccional Sánchez Ramírez','miembro20@CLDCI-025.org','001-0000020-9','(809) 329-2585',NULL,NULL,'Comunicador','activa','estudiante','2025-01-05','CLDCI-025-2025-020',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('2d2ec4d0-400f-49e3-9c15-b6e819403a71','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 20 de CLDCI Seccional Santiago','miembro20@CLDCI-030.org','001-0000020-4','(809) 299-7364',NULL,NULL,'Locutor','activa','activo','2025-02-27','CLDCI-030-2025-020',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('2fa48a71-9553-4ad7-a59e-034aaaa1f476','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 19 de CLDCI Seccional Elías Piña','miembro19@CLDCI-008.org','001-0000019-9','(809) 829-7017',NULL,NULL,'Locutor','activa','estudiante','2025-05-28','CLDCI-008-2025-019',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('3081e02e-9bfc-4cf3-8e28-501bf5a82f00','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 7 de CLDCI Seccional Elías Piña','miembro7@CLDCI-008.org','001-0000007-6','(809) 359-3722',NULL,NULL,'Comunicador','activa','activo','2025-06-02','CLDCI-008-2025-007',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('3087e0a5-1b6d-4fb7-a14b-866b1d601333','d2363643-ab0a-4d6a-b117-f99ab9cfee29',NULL,'María Rodríguez López','maria.rodriguez@cldci.org','001-2345678-9','(809) 234-5678',NULL,NULL,'Presentadora','activa','activo','2019-06-20','CLDCI-2019-002',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 08:09:25','2025-10-19 08:09:25'),('33ba4c1f-6e35-45e5-8262-144afe820446','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 4 de CLDCI Seccional Elías Piña','miembro4@CLDCI-008.org','001-0000004-7','(809) 314-5942',NULL,NULL,'Locutor','activa','estudiante','2025-01-11','CLDCI-008-2025-004',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('37caaebc-606e-4585-bd84-622889cd68ea','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 16 de CLDCI Seccional Elías Piña','miembro16@CLDCI-008.org','001-0000016-1','(809) 366-4058',NULL,NULL,'Locutor','activa','activo','2025-05-23','CLDCI-008-2025-016',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('38d5ea45-bce6-438c-8cc9-a5a2a2a21103','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 11 de CLDCI Seccional Santiago','miembro11@CLDCI-030.org','001-0000011-1','(809) 501-6263',NULL,NULL,'Periodista','activa','activo','2025-02-18','CLDCI-030-2025-011',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('39be2289-d309-446a-bec2-bae59bc7017d','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 19 de CLDCI Seccional Azua','miembro19@CLDCI-002.org','001-0000019-9','(809) 320-7322',NULL,NULL,'Comunicador','activa','estudiante','2025-02-15','CLDCI-002-2025-019',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('3d524668-3d6d-403a-a0a4-30517588ba9c','d2363643-ab0a-4d6a-b117-f99ab9cfee29',NULL,'Juan Pérez García','juan.perez@cldci.org','001-1234567-8','(809) 123-4567',NULL,NULL,'Locutor','activa','activo','2020-01-15','CLDCI-2020-001',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 08:09:25','2025-10-19 08:09:25'),('3e65df3e-317f-4516-bfb7-1fe2e5234cf6','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 13 de CLDCI Seccional Santiago Rodríguez','miembro13@CLDCI-031.org','001-0000013-6','(809) 695-8093',NULL,NULL,'Locutor','activa','fundador','2025-07-15','CLDCI-031-2025-013',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('3f833b16-de7a-415a-bad5-94a9a7f48f76','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 8 de CLDCI Seccional Santiago','miembro8@CLDCI-030.org','001-0000008-1','(809) 168-9199',NULL,NULL,'Comunicador','activa','fundador','2025-08-13','CLDCI-030-2025-008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('4c549b2e-3c04-402a-a08b-c84e1c5252ed','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 6 de CLDCI Seccional Azua','miembro6@CLDCI-002.org','001-0000006-6','(809) 415-2283',NULL,NULL,'Locutor','activa','estudiante','2025-06-01','CLDCI-002-2025-006',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('53463332-790f-4c16-a334-6ba035c0ddae','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 9 de CLDCI Seccional Santiago Rodríguez','miembro9@CLDCI-031.org','001-0000009-3','(809) 914-4465',NULL,NULL,'Comunicador','activa','estudiante','2025-05-18','CLDCI-031-2025-009',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('555d0c27-ffaf-4d04-bd44-5372bc0693b4','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 5 de CLDCI Seccional Santiago Rodríguez','miembro5@CLDCI-031.org','001-0000005-1','(809) 799-3921',NULL,NULL,'Comunicador','activa','estudiante','2025-04-15','CLDCI-031-2025-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('57f05127-2f63-45d7-8ee3-a4be0a8e0e69','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 14 de CLDCI Seccional Sánchez Ramírez','miembro14@CLDCI-025.org','001-0000014-4','(809) 763-9566',NULL,NULL,'Locutor','activa','estudiante','2025-02-13','CLDCI-025-2025-014',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('59158551-6a3a-4dd9-ba0f-33b9084fec78','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 10 de CLDCI Seccional Elías Piña','miembro10@CLDCI-008.org','001-0000010-6','(809) 822-6838',NULL,NULL,'Periodista','activa','estudiante','2025-05-29','CLDCI-008-2025-010',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('5bdfc3ee-6e24-4c8a-ad2a-85c637337edb','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 14 de CLDCI Seccional Azua','miembro14@CLDCI-002.org','001-0000014-9','(809) 390-3495',NULL,NULL,'Comunicador','activa','estudiante','2024-10-26','CLDCI-002-2025-014',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('5d3dbbe4-6047-4e1b-9364-0165e3382f3a','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 12 de CLDCI Seccional Azua','miembro12@CLDCI-002.org','001-0000012-1','(809) 714-3460',NULL,NULL,'Comunicador','activa','activo','2025-08-18','CLDCI-002-2025-012',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('5ef6ec4e-cca5-44d7-aac3-d4c97a0c92ed','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 5 de CLDCI Seccional Elías Piña','miembro5@CLDCI-008.org','001-0000005-7','(809) 400-6813',NULL,NULL,'Comunicador','activa','estudiante','2025-07-22','CLDCI-008-2025-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('60bee083-1db0-47e4-8e9a-72f3a6f3b3ba','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 12 de CLDCI Seccional Elías Piña','miembro12@CLDCI-008.org','001-0000012-8','(809) 748-6127',NULL,NULL,'Locutor','activa','fundador','2025-02-10','CLDCI-008-2025-012',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('656b8667-278f-45bc-9816-327d2aab4d34','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 8 de CLDCI Seccional Santiago Rodríguez','miembro8@CLDCI-031.org','001-0000008-9','(809) 776-2541',NULL,NULL,'Locutor','activa','activo','2025-06-09','CLDCI-031-2025-008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('66ad44e9-be2f-40e5-a04b-b3e5e3e90e9e','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 15 de CLDCI Seccional Sánchez Ramírez','miembro15@CLDCI-025.org','001-0000015-6','(809) 511-9911',NULL,NULL,'Periodista','activa','activo','2025-04-26','CLDCI-025-2025-015',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('6d0ddde6-86b0-4bc4-b1ee-b463c59dca90','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 2 de CLDCI Seccional Santiago Rodríguez','miembro2@CLDCI-031.org','001-0000002-1','(809) 426-5302',NULL,NULL,'Periodista','activa','activo','2025-03-22','CLDCI-031-2025-002',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('6fc78880-9b4e-4b49-8982-afa1363bd832','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 13 de CLDCI Seccional Santiago','miembro13@CLDCI-030.org','001-0000013-2','(809) 950-4933',NULL,NULL,'Periodista','activa','activo','2025-09-07','CLDCI-030-2025-013',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('7142fec3-f54a-4edc-b544-b414f977c112','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 17 de CLDCI Seccional Elías Piña','miembro17@CLDCI-008.org','001-0000017-3','(809) 403-3047',NULL,NULL,'Periodista','activa','fundador','2024-11-23','CLDCI-008-2025-017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('767b6bcb-b80d-4e2f-9095-3b0c83761c67','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 9 de CLDCI Seccional Elías Piña','miembro9@CLDCI-008.org','001-0000009-9','(809) 953-2442',NULL,NULL,'Locutor','activa','estudiante','2025-01-05','CLDCI-008-2025-009',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('7862d376-6306-4f26-8c4f-0340cef941b2','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 16 de CLDCI Seccional Santiago','miembro16@CLDCI-030.org','001-0000016-5','(809) 521-5216',NULL,NULL,'Locutor','activa','fundador','2025-06-12','CLDCI-030-2025-016',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('79a37739-11d0-433d-a63c-f6fdea613046','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 18 de CLDCI Seccional Sánchez Ramírez','miembro18@CLDCI-025.org','001-0000018-8','(809) 299-7542',NULL,NULL,'Comunicador','activa','estudiante','2025-03-14','CLDCI-025-2025-018',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('7c92da5f-c13d-4d54-af6c-59470f119263','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 4 de CLDCI Seccional Sánchez Ramírez','miembro4@CLDCI-025.org','001-0000004-3','(809) 723-7863',NULL,NULL,'Periodista','activa','estudiante','2025-02-17','CLDCI-025-2025-004',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('809ee8af-2584-4aa8-88e0-ac9cb6862c46','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 20 de CLDCI Seccional Santiago Rodríguez','miembro20@CLDCI-031.org','001-0000020-9','(809) 997-2901',NULL,NULL,'Periodista','activa','estudiante','2025-02-27','CLDCI-031-2025-020',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('81ee7b09-dc0a-475a-b9d6-b6c3e3fe5fb3','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 6 de CLDCI Seccional Santiago','miembro6@CLDCI-030.org','001-0000006-6','(809) 748-4082',NULL,NULL,'Comunicador','activa','activo','2024-10-27','CLDCI-030-2025-006',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('821591a2-5572-4024-a42d-fce5c19afbda','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 20 de CLDCI Seccional Elías Piña','miembro20@CLDCI-008.org','001-0000020-9','(809) 776-1341',NULL,NULL,'Comunicador','activa','fundador','2025-05-11','CLDCI-008-2025-020',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('874faf45-fa56-4c84-a59f-dcd643214823','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 10 de CLDCI Seccional Sánchez Ramírez','miembro10@CLDCI-025.org','001-0000010-4','(809) 381-2432',NULL,NULL,'Comunicador','activa','estudiante','2025-03-30','CLDCI-025-2025-010',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('8e85671a-79c3-489b-8d30-b9dbea04eabe','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 11 de CLDCI Seccional Elías Piña','miembro11@CLDCI-008.org','001-0000011-2','(809) 925-6645',NULL,NULL,'Periodista','activa','estudiante','2025-08-11','CLDCI-008-2025-011',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('90ba917e-1a04-4361-858b-a99c15351724','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 17 de CLDCI Seccional Azua','miembro17@CLDCI-002.org','001-0000017-8','(809) 616-7205',NULL,NULL,'Periodista','activa','estudiante','2025-03-20','CLDCI-002-2025-017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('915615f5-f7b7-4e28-af4c-edddd361634b','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 7 de CLDCI Seccional Azua','miembro7@CLDCI-002.org','001-0000007-5','(809) 590-4304',NULL,NULL,'Comunicador','activa','estudiante','2025-09-11','CLDCI-002-2025-007',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('93deb084-0ff1-4fac-ae9f-ef97629916ef','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 19 de CLDCI Seccional Santiago Rodríguez','miembro19@CLDCI-031.org','001-0000019-5','(809) 646-9473',NULL,NULL,'Periodista','activa','activo','2025-08-18','CLDCI-031-2025-019',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('9952d372-6138-4897-873e-097bbc2a810b','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 13 de CLDCI Seccional Sánchez Ramírez','miembro13@CLDCI-025.org','001-0000013-9','(809) 874-2098',NULL,NULL,'Periodista','activa','estudiante','2025-01-25','CLDCI-025-2025-013',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('99c535dc-be6c-46f5-a7f9-69e3ff499748','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 14 de CLDCI Seccional Santiago','miembro14@CLDCI-030.org','001-0000014-7','(809) 169-3614',NULL,NULL,'Comunicador','activa','activo','2025-07-19','CLDCI-030-2025-014',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('99f80ea2-ca0e-4f90-9c03-ce17dd882347','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 4 de CLDCI Seccional Azua','miembro4@CLDCI-002.org','001-0000004-2','(809) 931-5191',NULL,NULL,'Comunicador','activa','estudiante','2024-11-11','CLDCI-002-2025-004',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('9b860f80-de4b-49ec-bc67-680f8e9be950','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 11 de CLDCI Seccional Sánchez Ramírez','miembro11@CLDCI-025.org','001-0000011-8','(809) 373-4083',NULL,NULL,'Periodista','activa','activo','2025-05-14','CLDCI-025-2025-011',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('9c3a8897-eda7-482f-b5e6-da377d0fb2c2','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 15 de CLDCI Seccional Santiago Rodríguez','miembro15@CLDCI-031.org','001-0000015-2','(809) 874-1469',NULL,NULL,'Comunicador','activa','estudiante','2025-03-18','CLDCI-031-2025-015',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('9d3ddd96-efc1-4043-ad9a-1fda07bd189f','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 2 de CLDCI Seccional Elías Piña','miembro2@CLDCI-008.org','001-0000002-5','(809) 825-9543',NULL,NULL,'Comunicador','activa','activo','2025-08-08','CLDCI-008-2025-002',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('9dacb99f-eb55-478f-8cee-215269c4e80e','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 3 de CLDCI Seccional Sánchez Ramírez','miembro3@CLDCI-025.org','001-0000003-2','(809) 560-7767',NULL,NULL,'Locutor','activa','estudiante','2025-06-06','CLDCI-025-2025-003',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('a3172dd4-6f52-46e8-be5e-64bb2eb398c1','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 12 de CLDCI Seccional Santiago Rodríguez','miembro12@CLDCI-031.org','001-0000012-3','(809) 434-4555',NULL,NULL,'Periodista','activa','estudiante','2025-02-19','CLDCI-031-2025-012',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('a768be5d-325d-4d2a-b6fc-f8104140daa5','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 7 de CLDCI Seccional Santiago','miembro7@CLDCI-030.org','001-0000007-8','(809) 263-6643',NULL,NULL,'Locutor','activa','activo','2025-09-18','CLDCI-030-2025-007',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('a83e280e-9ba7-4b30-9ccd-ab13de19fa1f','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 16 de CLDCI Seccional Azua','miembro16@CLDCI-002.org','001-0000016-6','(809) 905-5888',NULL,NULL,'Comunicador','activa','fundador','2024-11-18','CLDCI-002-2025-016',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('a8dfc5dc-125d-40d9-a71b-a42ff63d2103','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 16 de CLDCI Seccional Sánchez Ramírez','miembro16@CLDCI-025.org','001-0000016-1','(809) 570-1366',NULL,NULL,'Periodista','activa','estudiante','2025-05-16','CLDCI-025-2025-016',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('acd42815-6e27-43b1-8c7b-65dcd18145c5','d2363643-ab0a-4d6a-b117-f99ab9cfee29',NULL,'Pedro Gómez Luna','pedro.gomez@cldci.org','001-1122334-4','(809) 222-3333',NULL,NULL,'Comunicador','activa','estudiante','2023-09-01','CLDCI-2023-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('ae733a98-32b4-4ebb-8790-2accbf91f7f3','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 18 de CLDCI Seccional Azua','miembro18@CLDCI-002.org','001-0000018-2','(809) 363-4174',NULL,NULL,'Periodista','activa','estudiante','2025-03-19','CLDCI-002-2025-018',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('ae8331df-4af8-4e70-861b-c67611bd0964','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 17 de CLDCI Seccional Santiago Rodríguez','miembro17@CLDCI-031.org','001-0000017-1','(809) 534-8443',NULL,NULL,'Periodista','activa','activo','2025-05-23','CLDCI-031-2025-017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('b05835e1-79b8-4b05-9516-247c73efc393','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 1 de CLDCI Seccional Elías Piña','miembro1@CLDCI-008.org','001-0000001-2','(809) 163-8838',NULL,NULL,'Comunicador','activa','activo','2025-03-21','CLDCI-008-2025-001',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('b299263f-2df3-4f15-ac36-6d4365482356','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 3 de CLDCI Seccional Azua','miembro3@CLDCI-002.org','001-0000003-1','(809) 522-6486',NULL,NULL,'Locutor','activa','fundador','2024-12-04','CLDCI-002-2025-003',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('b9ffd0a5-1b8d-4146-beee-3dafb97ae795','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 17 de CLDCI Seccional Sánchez Ramírez','miembro17@CLDCI-025.org','001-0000017-3','(809) 794-7160',NULL,NULL,'Periodista','activa','activo','2025-05-12','CLDCI-025-2025-017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('bab3260a-4122-4b14-917a-aeaa459d3a1a','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 15 de CLDCI Seccional Santiago','miembro15@CLDCI-030.org','001-0000015-7','(809) 991-3317',NULL,NULL,'Periodista','activa','estudiante','2025-03-28','CLDCI-030-2025-015',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('bb0f2cb8-049e-4b10-b586-09d3e7d51336','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 4 de CLDCI Seccional Santiago Rodríguez','miembro4@CLDCI-031.org','001-0000004-2','(809) 176-5314',NULL,NULL,'Periodista','activa','activo','2025-01-03','CLDCI-031-2025-004',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('bcb875af-b260-4205-a5ae-5171f24557e6','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 7 de CLDCI Seccional Santiago Rodríguez','miembro7@CLDCI-031.org','001-0000007-5','(809) 627-1453',NULL,NULL,'Comunicador','activa','estudiante','2025-03-04','CLDCI-031-2025-007',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('bdbf43c4-a3d0-45a3-b8b0-7e029ed88c2b','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 18 de CLDCI Seccional Elías Piña','miembro18@CLDCI-008.org','001-0000018-6','(809) 833-4537',NULL,NULL,'Locutor','activa','activo','2025-06-25','CLDCI-008-2025-018',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('c0dbc264-6f71-4486-aaa3-b631eaee8d36','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 13 de CLDCI Seccional Elías Piña','miembro13@CLDCI-008.org','001-0000013-1','(809) 921-1136',NULL,NULL,'Periodista','activa','estudiante','2025-05-29','CLDCI-008-2025-013',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('c52b7966-8877-493f-ab5d-b662b859d9f4','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 9 de CLDCI Seccional Santiago','miembro9@CLDCI-030.org','001-0000009-2','(809) 977-6225',NULL,NULL,'Periodista','activa','activo','2024-10-25','CLDCI-030-2025-009',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('c66cafb8-c3f9-48d7-b0be-93036cfc374b','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 10 de CLDCI Seccional Santiago Rodríguez','miembro10@CLDCI-031.org','001-0000010-7','(809) 191-9556',NULL,NULL,'Locutor','activa','activo','2025-01-30','CLDCI-031-2025-010',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('c98a946b-41f5-41d6-a42d-dc966750c213','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 20 de CLDCI Seccional Azua','miembro20@CLDCI-002.org','001-0000020-1','(809) 473-1720',NULL,NULL,'Locutor','activa','fundador','2025-04-17','CLDCI-002-2025-020',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('c9eceb32-5a5a-480d-9fc1-4afd8dda2081','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 19 de CLDCI Seccional Santiago','miembro19@CLDCI-030.org','001-0000019-1','(809) 150-3567',NULL,NULL,'Periodista','activa','fundador','2025-05-01','CLDCI-030-2025-019',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('cbbc725b-6e4a-4a5d-bc3a-3a6fbebb45aa','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 8 de CLDCI Seccional Sánchez Ramírez','miembro8@CLDCI-025.org','001-0000008-7','(809) 399-4418',NULL,NULL,'Comunicador','activa','fundador','2025-06-16','CLDCI-025-2025-008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('cc84285b-9f2e-4104-808f-671f3d05cd36','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 11 de CLDCI Seccional Santiago Rodríguez','miembro11@CLDCI-031.org','001-0000011-1','(809) 106-7309',NULL,NULL,'Locutor','activa','estudiante','2025-06-05','CLDCI-031-2025-011',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('ce5254cb-8b95-454a-b79a-c71b1761828f','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 10 de CLDCI Seccional Azua','miembro10@CLDCI-002.org','001-0000010-4','(809) 302-4864',NULL,NULL,'Locutor','activa','estudiante','2025-01-19','CLDCI-002-2025-010',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('d3a736fd-923d-45f6-aa29-00de719464f0','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 6 de CLDCI Seccional Elías Piña','miembro6@CLDCI-008.org','001-0000006-6','(809) 781-8289',NULL,NULL,'Periodista','activa','activo','2024-12-04','CLDCI-008-2025-006',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('d45223cb-6d22-4ba9-8a8c-197fc1b920be','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 7 de CLDCI Seccional Sánchez Ramírez','miembro7@CLDCI-025.org','001-0000007-1','(809) 867-2114',NULL,NULL,'Locutor','activa','fundador','2025-04-20','CLDCI-025-2025-007',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('d62c563a-7b7d-4831-a306-57e6f0efd51f','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 14 de CLDCI Seccional Elías Piña','miembro14@CLDCI-008.org','001-0000014-2','(809) 449-8197',NULL,NULL,'Locutor','activa','activo','2025-04-14','CLDCI-008-2025-014',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('d647582f-8e0b-4183-a7a7-587ece32a8a2','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 1 de CLDCI Seccional Sánchez Ramírez','miembro1@CLDCI-025.org','001-0000001-7','(809) 803-9575',NULL,NULL,'Periodista','activa','activo','2025-03-25','CLDCI-025-2025-001',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('d888075a-5374-49e2-a8d1-48e527ffab71','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 18 de CLDCI Seccional Santiago Rodríguez','miembro18@CLDCI-031.org','001-0000018-9','(809) 133-4507',NULL,NULL,'Locutor','activa','activo','2024-12-28','CLDCI-031-2025-018',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('dde38549-c68e-4f67-af23-a4a4d767b837','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 16 de CLDCI Seccional Santiago Rodríguez','miembro16@CLDCI-031.org','001-0000016-1','(809) 656-9780',NULL,NULL,'Locutor','activa','estudiante','2025-09-17','CLDCI-031-2025-016',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('e0f3eacf-bf31-4975-b486-c65ae5bcd22d','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 12 de CLDCI Seccional Sánchez Ramírez','miembro12@CLDCI-025.org','001-0000012-7','(809) 403-3363',NULL,NULL,'Periodista','activa','fundador','2025-07-29','CLDCI-025-2025-012',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('e3d2bd39-df43-44e7-8f4a-8455db85c123','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 5 de CLDCI Seccional Sánchez Ramírez','miembro5@CLDCI-025.org','001-0000005-9','(809) 348-2401',NULL,NULL,'Locutor','activa','activo','2025-06-23','CLDCI-025-2025-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('e49c4e0b-7ea0-4e3f-a5d4-cf279892ccb2','d2363643-ab0a-4d6a-b117-f99ab9cfee29',NULL,'Luis Hernández Torres','luis.hernandez@cldci.org','001-5678901-2','(809) 567-8901',NULL,NULL,'Locutor Deportivo','inactiva','activo','2017-12-01','CLDCI-2017-005',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 08:09:25','2025-10-19 08:09:25'),('e4ec678b-40c3-4109-9801-ea62297f24ad','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 9 de CLDCI Seccional Azua','miembro9@CLDCI-002.org','001-0000009-4','(809) 211-3839',NULL,NULL,'Locutor','activa','fundador','2024-12-10','CLDCI-002-2025-009',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('e531256f-9a61-4ee6-9edb-9fdf3e1eb22b','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 12 de CLDCI Seccional Santiago','miembro12@CLDCI-030.org','001-0000012-8','(809) 261-5464',NULL,NULL,'Locutor','activa','activo','2025-01-24','CLDCI-030-2025-012',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('ec55d3bc-eeb6-4f24-ae33-b6a0f93c1e28','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 4 de CLDCI Seccional Santiago','miembro4@CLDCI-030.org','001-0000004-1','(809) 361-5407',NULL,NULL,'Comunicador','activa','estudiante','2025-02-11','CLDCI-030-2025-004',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('ee0753ee-1984-44c2-be73-809eb41af209','0e3471b7-c1aa-480d-a47c-1a7c1992c40e',NULL,'Miembro 1 de CLDCI Seccional Santiago Rodríguez','miembro1@CLDCI-031.org','001-0000001-4','(809) 702-7316',NULL,NULL,'Periodista','activa','estudiante','2025-05-23','CLDCI-031-2025-001',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35'),('eed02ad1-8cf1-4d91-a239-aa578f06cf6e','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 15 de CLDCI Seccional Elías Piña','miembro15@CLDCI-008.org','001-0000015-1','(809) 272-8017',NULL,NULL,'Locutor','activa','estudiante','2025-02-26','CLDCI-008-2025-015',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('ef7543eb-9081-4451-a782-6a9387f44b45','131fd3af-a95b-47d9-909d-b9fa82b590a8',NULL,'Miembro 8 de CLDCI Seccional Elías Piña','miembro8@CLDCI-008.org','001-0000008-3','(809) 576-6460',NULL,NULL,'Locutor','activa','estudiante','2025-01-22','CLDCI-008-2025-008',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('f1e8d620-347e-408a-8937-6fb228c56e7a','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 13 de CLDCI Seccional Azua','miembro13@CLDCI-002.org','001-0000013-6','(809) 532-8920',NULL,NULL,'Periodista','activa','estudiante','2025-03-23','CLDCI-002-2025-013',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('f1fada80-c3fa-41c2-a46d-c9f7a16345a7','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 2 de CLDCI Seccional Azua','miembro2@CLDCI-002.org','001-0000002-2','(809) 603-2859',NULL,NULL,'Locutor','activa','activo','2025-08-15','CLDCI-002-2025-002',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('f6df0612-6006-4969-9a27-c48608c9a020','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 1 de CLDCI Seccional Azua','miembro1@CLDCI-002.org','001-0000001-4','(809) 931-3727',NULL,NULL,'Comunicador','activa','fundador','2025-03-15','CLDCI-002-2025-001',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:36','2025-10-19 19:39:36'),('f8157beb-7c76-41b6-a002-674e3258347b','0314201b-4aca-4a95-ac37-c867a24caeee',NULL,'Miembro 17 de CLDCI Seccional Santiago','miembro17@CLDCI-030.org','001-0000017-5','(809) 627-7579',NULL,NULL,'Comunicador','activa','estudiante','2024-12-11','CLDCI-030-2025-017',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:34','2025-10-19 19:39:34'),('fabbe423-6db9-4ff2-868b-f2c5fdb5049f','1564606e-87ae-4056-9ad3-fc756c73c89f',NULL,'Miembro 15 de CLDCI Seccional Azua','miembro15@CLDCI-002.org','001-0000015-7','(809) 588-8615',NULL,NULL,'Comunicador','activa','fundador','2025-06-02','CLDCI-002-2025-015',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:37','2025-10-19 19:39:37'),('ff10cabc-aede-4030-bd17-e9df9153153c','0b11d865-b816-4a50-a9d2-bb66efc65e0c',NULL,'Miembro 6 de CLDCI Seccional Sánchez Ramírez','miembro6@CLDCI-025.org','001-0000006-2','(809) 764-4551',NULL,NULL,'Comunicador','activa','activo','2025-01-24','CLDCI-025-2025-006',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-19 19:39:35','2025-10-19 19:39:35');
/*!40000 ALTER TABLE `miembros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `miembros_directivos`
--

DROP TABLE IF EXISTS `miembros_directivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `miembros_directivos` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `miembro_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organo_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cargo_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` enum('activo','finalizado','suspendido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activo',
  `es_presidente` tinyint(1) NOT NULL DEFAULT '0',
  `semblanza` text COLLATE utf8mb4_unicode_ci,
  `foto_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `miembros_directivos_miembro_id_foreign` (`miembro_id`),
  KEY `miembros_directivos_cargo_id_foreign` (`cargo_id`),
  KEY `miembros_directivos_organo_id_estado_index` (`organo_id`,`estado`),
  CONSTRAINT `miembros_directivos_cargo_id_foreign` FOREIGN KEY (`cargo_id`) REFERENCES `cargos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `miembros_directivos_miembro_id_foreign` FOREIGN KEY (`miembro_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE,
  CONSTRAINT `miembros_directivos_organo_id_foreign` FOREIGN KEY (`organo_id`) REFERENCES `organos_cldc` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `miembros_directivos`
--

LOCK TABLES `miembros_directivos` WRITE;
/*!40000 ALTER TABLE `miembros_directivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `miembros_directivos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_01_19_000001_create_cldci_schema',1),(5,'2025_10_19_192750_create_organizacions_table',2),(6,'2025_10_19_193130_add_missing_cldci_tables',3),(7,'2025_10_19_195212_create_organizaciones_table',2),(8,'2025_10_19_195234_create_miembros_table',2),(9,'2025_10_19_195257_create_periodos_directiva_table',2),(10,'2025_10_19_195315_create_asambleas_table',2),(11,'2025_10_19_195345_create_asistencia_asambleas_table',2),(12,'2025_10_19_195408_create_padrones_electorales_table',2),(13,'2025_10_19_195435_create_electores_table',2),(14,'2025_10_19_195457_create_elecciones_table',2),(15,'2025_10_19_195528_create_votos_table',2),(16,'2025_10_19_195551_create_transacciones_financieras_table',2),(17,'2025_10_19_195615_create_presupuestos_table',2),(18,'2025_10_19_195640_create_capacitaciones_table',2),(19,'2025_10_19_195705_create_inscripciones_capacitacion_table',2),(20,'2025_10_19_195729_create_documentos_legales_table',2),(21,'2025_10_19_195756_create_seccional_submissions_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizaciones`
--

DROP TABLE IF EXISTS `organizaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizaciones` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('nacional','seccional','seccional_internacional','diaspora') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provincia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ciudad` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado_adecuacion` enum('pendiente','en_revision','aprobada','rechazada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `miembros_minimos` int NOT NULL DEFAULT '15',
  `fecha_fundacion` date DEFAULT NULL,
  `organizacion_padre_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organizaciones_codigo_unique` (`codigo`),
  KEY `organizaciones_organizacion_padre_id_foreign` (`organizacion_padre_id`),
  KEY `organizaciones_tipo_pais_index` (`tipo`,`pais`),
  CONSTRAINT `organizaciones_organizacion_padre_id_foreign` FOREIGN KEY (`organizacion_padre_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizaciones`
--

LOCK TABLES `organizaciones` WRITE;
/*!40000 ALTER TABLE `organizaciones` DISABLE KEYS */;
INSERT INTO `organizaciones` VALUES ('0314201b-4aca-4a95-ac37-c867a24caeee','CLDCI Seccional Santiago','CLDCI-030','seccional','República Dominicana','Santiago',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('0b11d865-b816-4a50-a9d2-bb66efc65e0c','CLDCI Seccional Sánchez Ramírez','CLDCI-025','seccional','República Dominicana','Sánchez Ramírez',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('0e3471b7-c1aa-480d-a47c-1a7c1992c40e','CLDCI Seccional Santiago Rodríguez','CLDCI-031','seccional','República Dominicana','Santiago Rodríguez',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('131fd3af-a95b-47d9-909d-b9fa82b590a8','CLDCI Seccional Elías Piña','CLDCI-008','seccional','República Dominicana','Elías Piña',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('1564606e-87ae-4056-9ad3-fc756c73c89f','CLDCI Seccional Azua','CLDCI-002','seccional','República Dominicana','Azua',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('1e8e10cd-7002-4496-b923-ec1e0810246a','CLDCI Seccional Monseñor Nouel','CLDCI-018','seccional','República Dominicana','Monseñor Nouel',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('1f762d65-762f-4999-b23d-54e0eca89cad','CLDCI Seccional El Seibo','CLDCI-009','seccional','República Dominicana','El Seibo',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('24fd5ff0-fe62-4121-8925-2b458cedc12b','CLDCI Seccional Venezuela','CLDCI-INT-003','seccional_internacional','Venezuela',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('27856507-2f57-4a75-9d9e-2274f844caba','CLDCI Seccional San Pedro de Macorís','CLDCI-029','seccional','República Dominicana','San Pedro de Macorís',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('2a4d82e0-d17e-4fe5-8f88-1d83130ca544','CLDCI Seccional Peravia','CLDCI-022','seccional','República Dominicana','Peravia',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('2b6dc38c-5b62-46d1-9fc3-769e919714d6','CLDCI Seccional Brasil','CLDCI-INT-010','seccional_internacional','Brasil',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('338bcb05-ae06-4843-b1db-4836a74538ce','CLDCI Seccional Argentina','CLDCI-INT-009','seccional_internacional','Argentina',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('3be4b93f-41b5-4539-8f8d-c4f0f9f283ae','CLDCI Seccional Chile','CLDCI-INT-008','seccional_internacional','Chile',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('3d23df83-7d5a-4bd4-9ab9-2f59b1380e7d','CLDCI Seccional La Altagracia','CLDCI-014','seccional','República Dominicana','La Altagracia',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('45e0e4c7-b233-4d8e-99dc-90e6bab35a0a','CLDCI Seccional Santo Domingo','CLDCI-032','seccional','República Dominicana','Santo Domingo',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('5b21415a-9a10-4a0b-a1bc-74224b14d8b3','CLDCI Seccional Monte Plata','CLDCI-020','seccional','República Dominicana','Monte Plata',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('5d7f5c0d-ce8e-4be4-a667-00f3a0949e27','CLDCI Seccional Distrito Nacional','CLDCI-006','seccional','República Dominicana','Distrito Nacional',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('60f6ffa8-b738-496e-b851-9d30651a90ad','CLDCI Seccional Duarte','CLDCI-007','seccional','República Dominicana','Duarte',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('7273de6d-c37a-4e0e-ba0b-dac2d94daad4','CLDCI Seccional San Juan','CLDCI-028','seccional','República Dominicana','San Juan',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('799e21a3-8332-464b-9140-d821adfec3be','CLDCI Seccional San José de las Matas','CLDCI-034','seccional','República Dominicana','San José de las Matas',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('7d6bbc1c-7d45-4281-98ff-9600bac52c7e','CLDCI Seccional México','CLDCI-INT-006','seccional_internacional','México',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('910c0e6f-829f-4750-bb05-9b83584abe0b','CLDCI Seccional San José de Ocoa','CLDCI-027','seccional','República Dominicana','San José de Ocoa',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('93bf2a6c-a983-498c-8f4d-66647ee2d48a','CLDCI Seccional Hermanas Mirabal','CLDCI-012','seccional','República Dominicana','Hermanas Mirabal',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('96b8848c-eb22-4330-8be7-08527e5d3ec3','CLDCI Seccional La Vega','CLDCI-016','seccional','República Dominicana','La Vega',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('99195fd1-2120-4274-bd65-a6902e399fa9','CLDCI Seccional Colombia','CLDCI-INT-007','seccional_internacional','Colombia',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('a165279d-57f9-4663-89f3-390a11b08255','CLDCI Seccional España','CLDCI-INT-002','seccional_internacional','España',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('a9a64a77-e8f2-4d1f-bae2-65b70031e89a','CLDCI Seccional Puerto Plata','CLDCI-023','seccional','República Dominicana','Puerto Plata',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('abfb9583-0311-47c1-9228-8ef9320efa2e','CLDCI Seccional Hato Mayor','CLDCI-011','seccional','República Dominicana','Hato Mayor',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('acfcffda-331a-4e97-8fc2-c6ea007ae219','CLDCI Seccional Dajabón','CLDCI-005','seccional','República Dominicana','Dajabón',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('af8524e9-209a-488d-b6fb-ac4a2d9b6a01','CLDCI Seccional Monte Cristi','CLDCI-019','seccional','República Dominicana','Monte Cristi',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('bb9c2f39-88be-4cc1-8f35-25395ffe5f07','CLDCI Seccional Independencia','CLDCI-013','seccional','República Dominicana','Independencia',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('c20ee6f7-5dec-4670-ae77-2bd3f5923a08','CLDCI Seccional San Cristóbal','CLDCI-026','seccional','República Dominicana','San Cristóbal',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('c23198f7-5c81-4730-a526-726a6df6c369','CLDCI Seccional Valverde','CLDCI-033','seccional','República Dominicana','Valverde',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('c74945bc-7957-4d80-a5cb-6ade5dc18408','CLDCI Seccional Samaná','CLDCI-024','seccional','República Dominicana','Samaná',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('c7b81451-e6d6-4d2a-b3f1-4232f66620b8','CLDCI Seccional Espaillat','CLDCI-010','seccional','República Dominicana','Espaillat',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('cd8e3003-9261-4f73-9ee1-43ac000a0b17','CLDCI Seccional Barahona','CLDCI-004','seccional','República Dominicana','Barahona',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('d2363643-ab0a-4d6a-b117-f99ab9cfee29','Círculo de Locutores Dominicanos Colegiados, Inc.','CLDCI-001','nacional','República Dominicana','Distrito Nacional','Santo Domingo','Ave. 27 de Febrero #1405, Plaza de la Cultura, Santo Domingo','(809) 686-2583','info@cldci.org.do','aprobada',100,'1990-03-15',NULL,'2025-10-19 08:06:05','2025-10-19 08:06:05'),('da0f9960-34af-4b1f-9236-5876da3f3446','CLDCI Seccional Baoruco','CLDCI-003','seccional','República Dominicana','Baoruco',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('e8d18a22-b219-45d8-b566-1a483c39a115','CLDCI Seccional La Romana','CLDCI-015','seccional','República Dominicana','La Romana',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12'),('ee0f2ff8-ea1e-4eb8-a09c-b22753cf56d7','CLDCI Seccional Puerto Rico','CLDCI-INT-004','seccional_internacional','Puerto Rico',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('effca02c-f26e-4fdf-b873-36080df50053','CLDCI Seccional Estados Unidos','CLDCI-INT-001','seccional_internacional','Estados Unidos',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('f086397e-da57-442f-a76a-9fd11bf50e8f','CLDCI Seccional Pedernales','CLDCI-021','seccional','República Dominicana','Pedernales',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('f49e9236-2c0a-43c1-b82f-ebc1e9b2e284','CLDCI Seccional Canadá','CLDCI-INT-005','seccional_internacional','Canadá',NULL,NULL,NULL,NULL,NULL,'pendiente',10,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:13','2025-10-19 08:08:13'),('f5afcd59-ddfd-4f85-a296-55405481d0ef','CLDCI Seccional María Trinidad Sánchez','CLDCI-017','seccional','República Dominicana','María Trinidad Sánchez',NULL,NULL,NULL,NULL,'pendiente',15,NULL,'d2363643-ab0a-4d6a-b117-f99ab9cfee29','2025-10-19 08:08:12','2025-10-19 08:08:12');
/*!40000 ALTER TABLE `organizaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizacions`
--

DROP TABLE IF EXISTS `organizacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizacions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizacions`
--

LOCK TABLES `organizacions` WRITE;
/*!40000 ALTER TABLE `organizacions` DISABLE KEYS */;
/*!40000 ALTER TABLE `organizacions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organos_cldc`
--

DROP TABLE IF EXISTS `organos_cldc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organos_cldc` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('direccion','consultivo','operativo','especializado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel_jerarquico` int NOT NULL DEFAULT '1',
  `organo_padre_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organos_cldc_organizacion_id_foreign` (`organizacion_id`),
  KEY `organos_cldc_organo_padre_id_foreign` (`organo_padre_id`),
  CONSTRAINT `organos_cldc_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `organos_cldc_organo_padre_id_foreign` FOREIGN KEY (`organo_padre_id`) REFERENCES `organos_cldc` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organos_cldc`
--

LOCK TABLES `organos_cldc` WRITE;
/*!40000 ALTER TABLE `organos_cldc` DISABLE KEYS */;
/*!40000 ALTER TABLE `organos_cldc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `padrones_electorales`
--

DROP TABLE IF EXISTS `padrones_electorales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `padrones_electorales` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `padrones_electorales_organizacion_id_activo_index` (`organizacion_id`,`activo`),
  CONSTRAINT `padrones_electorales_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `padrones_electorales`
--

LOCK TABLES `padrones_electorales` WRITE;
/*!40000 ALTER TABLE `padrones_electorales` DISABLE KEYS */;
INSERT INTO `padrones_electorales` VALUES ('42ee4354-cd9b-4bc3-99eb-24e32f75f92b','d2363643-ab0a-4d6a-b117-f99ab9cfee29','2024-2026','Padrón electoral para el período 2024-2026','2024-01-01','2026-12-31',1,NULL,'2025-10-19 19:41:54','2025-10-19 19:41:54');
/*!40000 ALTER TABLE `padrones_electorales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodos_directiva`
--

DROP TABLE IF EXISTS `periodos_directiva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `periodos_directiva` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `directiva` json NOT NULL,
  `acta_eleccion_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `periodos_directiva_organizacion_id_foreign` (`organizacion_id`),
  CONSTRAINT `periodos_directiva_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodos_directiva`
--

LOCK TABLES `periodos_directiva` WRITE;
/*!40000 ALTER TABLE `periodos_directiva` DISABLE KEYS */;
INSERT INTO `periodos_directiva` VALUES ('7c7748b8-0b28-4fe8-b367-33310c9d3e2b','d2363643-ab0a-4d6a-b117-f99ab9cfee29','2024-01-01','2026-12-31','{\"vocal1\": \"Carlos Sánchez Ruiz\", \"vocal2\": \"Laura Martínez López\", \"tesorero\": \"Ana Fernández Díaz\", \"presidente\": \"Juan Pérez García\", \"secretario\": \"Pedro Gómez Luna\", \"vicepresidente\": \"María Rodríguez Soto\"}','/documentos/acta-eleccion-2024.pdf',1,'2025-10-19 19:39:37','2025-10-19 19:39:37');
/*!40000 ALTER TABLE `periodos_directiva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuestos`
--

DROP TABLE IF EXISTS `presupuestos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presupuestos` (
  `id` char(36) NOT NULL,
  `organizacion_id` char(36) DEFAULT NULL,
  `periodo` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `monto_presupuestado` decimal(12,2) NOT NULL,
  `monto_ejecutado` decimal(12,2) DEFAULT '0.00',
  `activo` tinyint(1) DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuestos`
--

LOCK TABLES `presupuestos` WRITE;
/*!40000 ALTER TABLE `presupuestos` DISABLE KEYS */;
INSERT INTO `presupuestos` VALUES ('2f0745cb-bb23-4816-b886-1df7713daf4a','d2363643-ab0a-4d6a-b117-f99ab9cfee29','2024','operativo',120000.00,45000.00,1,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('ebe81a30-d77e-49a3-af8b-4c97037516e7','d2363643-ab0a-4d6a-b117-f99ab9cfee29','2024','equipos',40000.00,12000.00,1,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('f40045ef-1d35-4abf-af1a-2803f664e692','d2363643-ab0a-4d6a-b117-f99ab9cfee29','2024','capacitacion',60000.00,15000.00,1,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('fa59fb7e-01c8-49cc-aaf3-6b28444f6ed0','d2363643-ab0a-4d6a-b117-f99ab9cfee29','2024','eventos',80000.00,25000.00,1,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53');
/*!40000 ALTER TABLE `presupuestos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seccional_submissions`
--

DROP TABLE IF EXISTS `seccional_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seccional_submissions` (
  `id` char(36) NOT NULL,
  `seccional_nombre` varchar(255) NOT NULL,
  `directiva` text,
  `miembros_csv_path` varchar(255) DEFAULT NULL,
  `actas_paths` json DEFAULT NULL,
  `miembros_min_ok` tinyint(1) DEFAULT '0',
  `miembros_contados` int DEFAULT '0',
  `observaciones` text,
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seccional_submissions`
--

LOCK TABLES `seccional_submissions` WRITE;
/*!40000 ALTER TABLE `seccional_submissions` DISABLE KEYS */;
INSERT INTO `seccional_submissions` VALUES ('b671f3fe-e7ca-4bec-92b9-f2d428b8d5b7','CLDCI Seccional La Vega','Presidente: Roberto Silva, Secretario: Carmen López','/expedientes/lavega/miembros.csv','[\"/expedientes/lavega/acta1.pdf\"]',0,12,'Faltan 3 miembros para cumplir mínimo',NULL,'2025-10-19 19:59:54','2025-10-19 19:59:54'),('f1f67d7f-44d6-48b8-8e35-24b5641fa94f','CLDCI Seccional Santiago','Presidente: Ana García, Secretario: Luis Martínez','/expedientes/santiago/miembros.csv','[\"/expedientes/santiago/acta1.pdf\", \"/expedientes/santiago/acta2.pdf\"]',1,25,'Documentación completa, aprobada',NULL,'2025-10-19 19:59:54','2025-10-19 19:59:54');
/*!40000 ALTER TABLE `seccional_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seccionales`
--

DROP TABLE IF EXISTS `seccionales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seccionales` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('provincial','internacional') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provincia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ciudad` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `miembros_count` int NOT NULL DEFAULT '0',
  `fecha_fundacion` date DEFAULT NULL,
  `estado` enum('activa','suspendida','inactiva') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'activa',
  `coordinador_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seccionales_organizacion_id_foreign` (`organizacion_id`),
  KEY `seccionales_coordinador_id_foreign` (`coordinador_id`),
  CONSTRAINT `seccionales_coordinador_id_foreign` FOREIGN KEY (`coordinador_id`) REFERENCES `miembros` (`id`) ON DELETE SET NULL,
  CONSTRAINT `seccionales_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seccionales`
--

LOCK TABLES `seccionales` WRITE;
/*!40000 ALTER TABLE `seccionales` DISABLE KEYS */;
/*!40000 ALTER TABLE `seccionales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_audit_log`
--

DROP TABLE IF EXISTS `security_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_audit_log` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `success` tinyint(1) NOT NULL DEFAULT '1',
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `additional_data` json DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `security_audit_log_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `security_audit_log_action_created_at_index` (`action`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_audit_log`
--

LOCK TABLES `security_audit_log` WRITE;
/*!40000 ALTER TABLE `security_audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensitive_data_access_audit`
--

DROP TABLE IF EXISTS `sensitive_data_access_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensitive_data_access_audit` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessing_user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessed_member_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessed_fields` json NOT NULL,
  `justification` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sensitive_data_access_audit_accessed_member_id_foreign` (`accessed_member_id`),
  KEY `sensitive_data_access_audit_accessing_user_id_created_at_index` (`accessing_user_id`,`created_at`),
  CONSTRAINT `sensitive_data_access_audit_accessed_member_id_foreign` FOREIGN KEY (`accessed_member_id`) REFERENCES `miembros` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensitive_data_access_audit`
--

LOCK TABLES `sensitive_data_access_audit` WRITE;
/*!40000 ALTER TABLE `sensitive_data_access_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensitive_data_access_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transacciones_financieras`
--

DROP TABLE IF EXISTS `transacciones_financieras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transacciones_financieras` (
  `id` char(36) NOT NULL,
  `organizacion_id` char(36) DEFAULT NULL,
  `tipo` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `concepto` varchar(255) NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `fecha` date NOT NULL,
  `comprobante_url` varchar(255) DEFAULT NULL,
  `metodo_pago` varchar(255) DEFAULT NULL,
  `referencia` varchar(255) DEFAULT NULL,
  `aprobado_por` varchar(255) DEFAULT NULL,
  `observaciones` text,
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transacciones_financieras`
--

LOCK TABLES `transacciones_financieras` WRITE;
/*!40000 ALTER TABLE `transacciones_financieras` DISABLE KEYS */;
INSERT INTO `transacciones_financieras` VALUES ('0e1e5a33-26ab-45cc-a598-d975aab64a9a','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ingreso','eventos','Inscripciones - Curso de Locución',12500.00,'2025-10-04',NULL,'efectivo',NULL,NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('3c3de297-97a7-47b9-aa60-394f6b18abc8','d2363643-ab0a-4d6a-b117-f99ab9cfee29','gasto','operativo','Alquiler sede - Enero 2024',8000.00,'2025-09-24',NULL,'transferencia','TRF-2024-003',NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('92d702df-6b24-4850-9283-e3430c7040b0','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ingreso','membresia','Cuotas de Membresía - Enero 2025',125000.00,'2025-10-17',NULL,'transferencia','CUOTAS-2025-01','admin','Recaudación de cuotas de membresía del mes de enero','admin','2025-10-19 21:38:12','2025-10-19 21:38:12'),('a7233f51-973f-493d-ad6f-ff1f9be51045','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ingreso','cuotas','Cuotas de membresía - Enero 2024',15000.00,'2025-09-19',NULL,'transferencia','TRF-2024-001',NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('dc0fe3b1-a254-4abb-93f4-f8fd7b2900f4','d2363643-ab0a-4d6a-b117-f99ab9cfee29','gasto','eventos','Catering - Asamblea General',3500.00,'2025-10-14',NULL,'efectivo',NULL,NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('e38ff4e8-55a6-42a0-b227-657cf5b912d1','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ingreso','patrocinios','Patrocinio - Empresa ABC',25000.00,'2025-10-09',NULL,'transferencia','TRF-2024-002',NULL,NULL,NULL,'2025-10-19 19:59:53','2025-10-19 19:59:53'),('fd45c968-7cdb-45d8-9265-f9d962daa7ed','d2363643-ab0a-4d6a-b117-f99ab9cfee29','ingreso','donacion','Donación Empresarial',75000.00,'2025-10-14',NULL,'cheque','DON-2025-001','admin','Donación de empresa patrocinadora','admin','2025-10-19 21:38:12','2025-10-19 21:38:12');
/*!40000 ALTER TABLE `transacciones_financieras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','moderador','miembro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'miembro',
  `organizacion_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_roles_user_id_organizacion_id_unique` (`user_id`,`organizacion_id`),
  KEY `user_roles_organizacion_id_foreign` (`organizacion_id`),
  CONSTRAINT `user_roles_organizacion_id_foreign` FOREIGN KEY (`organizacion_id`) REFERENCES `organizaciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin CLDCI','admin@cldci.org','2025-10-19 07:56:05','$2y$12$wrDTyPZD9Atb8bhCWZB90.qbj.N7kgzYbTi/SvmeOuofMFWXLFzeq',NULL,'2025-10-19 07:56:05','2025-10-19 07:56:05'),(2,'Miembros CLDCI','miembros@cldci.org','2025-10-19 07:56:09','$2y$12$6iw8PWqUxgrbOtOVpzBJP.5HKTT2TzlNG4F0B7yDVKiChizU3Y6Q6',NULL,'2025-10-19 07:56:09','2025-10-19 07:56:09'),(3,'Directiva CLDCI','directiva@cldci.org','2025-10-19 07:56:13','$2y$12$ku9HsgyRqhDDnybNnuFx7uaCv4Msi3aiA4AZHfIjok0OJouOoUS.2',NULL,'2025-10-19 07:56:13','2025-10-19 07:56:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cldc_database'
--

--
-- Dumping routines for database 'cldc_database'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-20  9:57:23
